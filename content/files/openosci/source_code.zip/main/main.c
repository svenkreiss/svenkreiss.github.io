//**********************************************************************************
//********************************            **************************************
//********************************  U-Sketch  **************************************
//********************************            **************************************
//**********************************************************************************

/* \file
*  \brief main, source
* 
*  Contains the main method.
* 
*  ca. 01/01/2006<br />
*  Sven Kreiss
*/




#include <main.h>

void interrupt_init(void);
void init_ports(void);
void call_inits(void);




void init_ports(void)
{
	DDRA=255;	//OUTPUT
	PORTA=255;	//on

	DDRC = 0;		//Input
	PORTC = 255;	//pull ups
	DDRD = (1<<PD3);	//PD3 Output
	PORTD = 255;
	DDRE = 0;	//input
	PORTE = 255;
}

void call_inits(void)
{
	init_ports();
	menu_init();
	control_init();
	input_init();
	adc_init(0);
	disp_init();
	usart_init();
	interrupt_init();
}





//*******************************   TIMER   **************************************


/**
 * Enables Timer2 for Backlight.
 * Enables Timer3 for micro-second measurement.
 * Enables interrupts globally.
 */
void interrupt_init()
{
	//timer 2 in fast PWM for backlight
	PORTB &= ~(1<<PB7);
	DDRB |= (1<<PB7); 	//OC2 pin is output
	TCCR2 = (1<<WGM21) | (1<<WGM20) | (1<<COM21) | (1<<CS20); //no prescaler
	TCNT2 = 0;
	OCR2 = 108; //max 120

	//timer 3 for us_timer
	us_timer_init();

	// enable interrupts
    sei();		
}



/** Form defined through the first function-pointer in 
 *  struct menue_prop_struct in menu.h. */
void bk_LED(int8_t value)
{
	if(value >= 1 && value <= 11) OCR2 = (value-1) * 12;	//10*12 = 120
}




//*******************************   MAIN   **************************************

/** Main, with test-code. */
int main (void)
{
	//#define cnt  1
	DDRE = (1<<PE2); //sets data direction for xck0 to output

	call_inits();
	#ifdef DISP_SPLASH
		for(uint32_t x=0; x < 5000000; x++) asm("nop");
	#endif

	while(1==1){
		//uart_empfang();
		control_refresh();
		disp_refresh();
		input_refresh();
	}
}
