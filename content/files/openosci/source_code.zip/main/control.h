/** \file
*  \brief control
* 
*  Control-backend. 
*  
*  \todo !!! Need to think about this concept again !!!
*  Only control_refresh() is not empty :-S .
* 
*  13 December 2005<br />
*  Sven Kreiss
*/


#ifndef _CONTROL_H
#define _CONTROL_H

#include "main.h"


void control_init(void);	///< initialise control
void control_refresh(void);	///< refresh control


void control_play(void);	///< the control function for mode "play"
void control_graph(void);	///< the control function for mode "graph"
void control_term(void);	///< the control function for mode "term"


#endif /* _CONTROL_H */
