/* \file
*  \brief input
* 
*  Handles the button events.
* 
*  12 Octobre 2005<br />
*  Sven Kreiss
*/

#include "input.h"


// Declarations
int8_t joy_adc_ready = 0;
void (*taste[8])(void);
void (*taste_long[8])(void);
void voidfunc(void){}

void tasten_status(void);

	
	
//Definitions	
	
void switch_off(void){
	disp_off();
	PORTA = 0;
}

void input_init(void){
	taste[0] = &menu_main_incr;
	taste[1] = &menu_start;
	taste[2] = &menu_left;
	taste[3] = &menu_up;
	taste[4] = &menu_down;
	taste[5] = &menu_right;
	taste[6] = &voidfunc;
	taste[7] = &voidfunc;
	taste_long[0] = &switch_off;
	taste_long[1] = &voidfunc;
	taste_long[2] = &voidfunc;
	taste_long[3] = &voidfunc;
	taste_long[4] = &voidfunc;
	taste_long[5] = &voidfunc;
	taste_long[6] = &voidfunc;
	taste_long[7] = &voidfunc;
}

/** this function needs to be called regularly in order to register all 
 * button events.
 * \bug With prescaler 7 input_refresh() does not get called often enough.
 * \todo Copy code from tasten_status() directly in here?
 */
void input_refresh(void){
	tasten_status();
}




void tasten_status (void){
	static uint8_t taster = 255;
	static uint32_t last_down = 0;

	uint8_t taster_neu = PINC;
	uint8_t diff = taster_neu ^ taster; //contains changes; "^" is xor
	diff &= taster_neu; //on_release; substitute taster_neu to taster to get on_push

	//if(count < 65535) count++;
	double timeFromLastDown = us_time_get_difference_d(last_down);
	#define ENTPR 1000
	#define PRESS_LONG 1000000
	if(timeFromLastDown > ENTPR){	//entprellen: sicherstellen, dass bestimmte Zeit vergangen ist
		if     (bit_is_set(diff,0)) taste[0]();		//Taste 1
		else if(bit_is_set(diff,1)) taste[1]();		//TASTE 2
		else if(bit_is_set(diff,2)) taste[2]();		//TASTE 3
		else if(bit_is_set(diff,3)) taste[3]();		//TASTE 4
		else if(bit_is_set(diff,4)) taste[4]();		//TASTE 5
		else if(bit_is_set(diff,5)) taste[5]();		//TASTE 6
		else if(bit_is_set(diff,6)) taste[6]();		//TASTE 7
		else if(bit_is_set(diff,7)) taste[7]();		//TASTE 8
	}
	if(taster != taster_neu) last_down = us_time_get();		//entprelltime neu setzen
	timeFromLastDown = us_time_get_difference_d(last_down);
	if(timeFromLastDown > PRESS_LONG){
		if     (bit_is_clear(taster_neu,0) && bit_is_clear(diff,0)) taste_long[0]();
		else if(bit_is_clear(taster_neu,1) && bit_is_clear(diff,1)) taste_long[1]();
		else if(bit_is_clear(taster_neu,2) && bit_is_clear(diff,2)) taste_long[2]();
		else if(bit_is_clear(taster_neu,3) && bit_is_clear(diff,3)) taste_long[3]();
		else if(bit_is_clear(taster_neu,4) && bit_is_clear(diff,4)) taste_long[4]();
		else if(bit_is_clear(taster_neu,5) && bit_is_clear(diff,5)) taste_long[5]();
		else if(bit_is_clear(taster_neu,6) && bit_is_clear(diff,6)) taste_long[6]();
		else if(bit_is_clear(taster_neu,7) && bit_is_clear(diff,7)) taste_long[7]();
	}
	taster = taster_neu;
}
