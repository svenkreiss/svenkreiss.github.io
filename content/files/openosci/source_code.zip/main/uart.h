/** \file
*  \brief UART
* 
*  Serial communication.
*  \todo All the functions need to be completed.
*  \todo Peter Fleury's lib?
* 
*  ca 01 January 2006<br />
*  Sven Kreiss
*/

#ifndef UART_FUNKTIONEN_H
#define UART_FUNKTIONEN_H

#include "main.h"
//#include <avr/crc16.h>
//#include <avr/signal.h>
//#include <avr/interrupt.h>

#define UART_RX_BUFFER_SIZE 8
#define UART_TX_BUFFER_SIZE 8
#include "../libs/uartlibrary/uart.h"

void usart_init(void);				///< initialises both USARTs
void usart_off(void);				///< switches off both USARTs
void usart_baudrate(int8_t br);		///< property: sets baudrate
void usart_setSync(int8_t enable);	///< property: enables synchronous communication
void usart_stopBits(int8_t sb);		///< property: sets the nr of stop bits
void usart_dataBits(int8_t db);		///< property: sets the nr of data bits


#endif
