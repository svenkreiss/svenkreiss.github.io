/** \mainpage
* 
* \section thanks_sec Thanks!
*  Thanks to all the people who write open source code. This project is based
*  on a couple of other projects (barely did anything myself):
*    - Hagen Reddmann's and Christian Kranz's glcd lib for the Siemens S65 display
*    - Peter Fleury's UART lib
*    - of course: the avr-libc project
*
*  Hope I did not forget anyone.
*
* \section license_sec License
*  This program is free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Library General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* 
* \section doc_sec Documentation
* An up-to-date HTML and PDF version of the documentation is located at 
* http://www.svenkreiss.com/private/openosci.php .
*
*
* \section installation_sec Installation
* The easiest way to install the code should be to program the fuse bits,
* download the *.hex-file and write it directly to the controller.
* 
*
* \section fusebits_sec FuseBits
* Be very careful with these commands. It is absolutely necessary that
* you know in detail what each of these does and whether you can apply them
* to your system.
*
* read ext fuse bits:<br />
*	<i>avrdude -c avr910 -p m128 -P /dev/ttyUSB0 -U efuse:r:-:r | xxd</i>
*
* write ext fuse (m103C off, watchdog off):<br />
*	<i>avrdude -c avr910 -p m128 -P /dev/ttyUSB0 -U efuse:w:0xFF:m</i><br />
* write high fuse (disable JTAG, CKOPT to 0 for high freq cryst > 8MHz):<br />
*	<i>avrdude -c avr910 -p m128 -P /dev/ttyUSB0 -U hfuse:w:0xC9:m</i><br />
* write low fuse (switch to external chrystal osc):<br />
*	<i>avrdude -c avr910 -p m128 -P /dev/ttyUSB0 -U lfuse:w:0xEF:m</i><br />
*
* 
* \section contact_sec Contact
* <b>Sven Kreiss</b><br />
* eMail: sk@svenkreiss.com -- sk at svenkreiss dot com<br />
* web: http://www.svenkreiss.com/ -- www dot svenkreiss dot com
* 
*/

/** \file
*  \brief main
* 
*  Contains the main method.
* 
*  ca. 01/01/2006<br />
*  Sven Kreiss
*/





#ifndef MAIN_H
#define MAIN_H

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>



// ********  intern:  ***********
#include "menu.h"
#include "control.h"
#include "input.h"
#include "display.h"
#include "uart.h"
#include "adc.h"

#include "ustimer.h"


void bk_LED(int8_t value);	///< Function to connect to property "Backlight brightness".


#endif
