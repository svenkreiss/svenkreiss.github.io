/** \file
*  \brief input
* 
*  Handles the button events.
* 
*  12 Octobre 2005<br />
*  Sven Kreiss
*/

#ifndef INPUT_H
#define INPUT_H

#include <inttypes.h>
#include <avr/io.h>
#include <avr/eeprom.h>
#include <avr/signal.h>

#include "main.h"


void input_init(void);		///< initialises the input
void input_refresh(void);	///< refreshes the input

#endif
