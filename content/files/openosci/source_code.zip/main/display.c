/*
 *		display.c
 *
 *		Sven Kreiss
 *		03 April 2006
 */



#include "display.h"


#include "avr/pgmspace.h"
#ifdef DISP_SPLASH
	#include "pics/boot.h"
#endif


#define BkColor BLACK
#define FgColor YELLOW
#define ShColor BLUE


/** Calls the lib's routine to init the display. Displays the splash-screen.
 *  Sets the font. Sets the window for text-output. */
void disp_init(void){
	//**** Hardware ****
	#ifndef USE_AUTOINIT
		glcdDisplayInit();
	#endif

	#ifdef DISP_SPLASH
		disp_load_bitmap();
	#else
		disp_clean();
	#endif

    glcd_Flags.AutoLineFeed = 0;
    glcdSelectFont(f8x11, 0); // font is stored in FLASH, thus no need for own read callback
	fdevopen(glcdPut,NULL,0);

	//window for text-output
	glcd_Window.X1 = 5;
	glcd_Window.X2 = 110;
	glcd_Window.Y1 = 16;
	glcd_Window.Y2 = 162;
}

/** The original shutdown sequence for the display is not known. 
 *  The current workaround is to activate the stand-by for the display. */
void disp_off(void){
	bk_LED(1);
	//for(uint32_t x=0; x < 5000000; x++) asm("nop");

	//clean
	glcdSetAddr(0,0, 131, 175);   // set RAM access pointer of display
	//width and height also defined in header
	for(uint8_t x = 0; x < 132; x++){
		for(uint8_t y = 0; y < 176; y++){
			glcdPutPixel(WHITE);
		}
	}
	for(uint32_t x=0; x < 500000; x++) asm("nop");
	glcdDisplayOff();
	glcdWait(100);
}

void disp_refresh(void){
	disp_menu();
	menu_mains[menu_now-1].disp_func();
	disp_prop();
}

/** Refreshes the menu bar when the menu has changed. */
void disp_menu(void){
	static int8_t main_old = 0;

	//*** left ***
	if(menu_now != main_old){
		main_old = menu_now;
		disp_clean();


		glcdFillRect(0,0,132,13,ShColor); //shadow color for menu bg
		#define SPACELEFT 6
		for(uint8_t x=0; x < MENU_ANZ_MAIN; x++){
			if(menu_now == (x+1)){
				glcdFillRect(SPACELEFT+x*40,1, SPACELEFT+(x+1)*40,12, BkColor);
				glcdSetColors(FgColor, BkColor);
			}else{
				glcdSetColors(FgColor, ShColor);
			}
			uint8_t w = glcdCharsWidth(menu_mains[x].name, 0);
			glcdMoveTo(SPACELEFT+21+x*40 - w/2, 2);
			printf(menu_mains[x].name);
		}
	}
}

/** Refreshes the property bar if the menu, the property or the value of the
 * property has changed. */
void disp_prop(void){
	static int8_t main_old = 0;
	static int8_t prop_old = 0;
	static int8_t value_old = 0;

	if(	menu_now != main_old ||
		MENU_CURRENT_PROP_NR != prop_old ||
		MENU_PROP_NOW.current_value != value_old){

		main_old = menu_now;
		prop_old = MENU_CURRENT_PROP_NR;
		value_old = MENU_PROP_NOW.current_value;

		#define DISP_PROP_W	33
		glcdFillRect(0, 162, 132, 176, ShColor);
		for(uint8_t x=0; x < 3; x++){
			if(x == 1){
				glcdFillRect(SPACELEFT+x*DISP_PROP_W,163, SPACELEFT+(x+1)*DISP_PROP_W,174, BkColor);
				glcdSetColors(FgColor, BkColor);
			}else{
				glcdSetColors(FgColor, ShColor);
			}
			int8_t current_value = value_old-1+x;
			char *label;
			if(current_value < 1)
				label = "=>";
			else if(current_value > MENU_PROP_NOW.nr_values)
				label = "<=";
			else
				label = MENU_PROP_NOW.value_name[current_value-1];
			uint8_t w = glcdCharsWidth(label, 0);
			glcdMoveTo(SPACELEFT+21+x*DISP_PROP_W - w, 164);
			printf(label);

			//prop-name
			w = glcdCharsWidth(MENU_PROP_NOW.prop_name, 0);
			glcdFillRect(132 - 2*SPACELEFT - w, 163, 130, 174, BkColor);
			glcdSetColors(FgColor, BkColor);
			glcdMoveTo(132 - SPACELEFT - w, 164);
			printf(MENU_PROP_NOW.prop_name);
		}
	}
}

#ifdef DISP_SPLASH
	void disp_load_bitmap(void){
		uint8_t data = 0;
		uint8_t pixel[3];

//		glcdSetAddr(0,0, 131, 175);   // set RAM access pointer of display
		glcdSetAddr(0,0, width, height);   // set RAM access pointer of display

		//width and height also defined in header
		for(uint8_t x = 0; x < width; x++){
			for(uint8_t y = 0; y < height; y++){
				data = pgm_read_byte(&header_data[y*width + x]);
				HEADER_PIXEL(data, pixel);
				glcdPutPixel(RGB(pixel[0], pixel[1], pixel[2]));
			}
		}
	}
#endif

void disp_clean(void){
	glcdSetAddr(0,0, 131, 175);   // set RAM access pointer of display
	//glcdSetBkColor(BkColor);

	//width and height also defined in header
	for(uint8_t x = 0; x < 132; x++){
		for(uint8_t y = 0; y < 176; y++){
			glcdPutPixel(BkColor);
		}
	}
}



//-----------------------------------------------------------
//
//			methods
//
//			which are called by "menu"
//
//-----------------------------------------------------------

void disp_debugging(void) {
	glcdSetColors(WHITE,BkColor);

	static uint16_t count = 0;
	int8_t y = 30;
	glcdMoveTo(20,y+=11); printf(" Count: %d    \n",count++);
	glcdMoveTo(20,y+=11); printf(" Menue: %d    \n",(uint16_t)ADCSRA);
	glcdMoveTo(20,y+=11); printf(" Presc: %d    \n",(uint16_t)(ADCSRA & ADIF));
	glcdMoveTo(20,y+=11); printf(" spi_control: %d   \n",SPCR);
	glcdMoveTo(20,y+=11); printf(" spi_status: %d   \n",SPSR);
}

/** The terminal for the serial interface.
 *  \todo Testing necessary! */
void disp_terminal(void) {
//	if(glcd_Cursor.X < 5 || glcd_Cursor.Y < 16 || glcd_Cursor.Y > 162) glcdMoveTo(5,16);
	if(glcd_Cursor.X < 5 || glcd_Cursor.Y < 16 || glcd_Cursor.Y > 162 || glcd_Cursor.X > 100) glcdMoveTo(5,16);
	glcdSetColors(WHITE,BkColor);

	uint16_t rx_data;
	while(! ((rx_data=uart_getc()) & UART_NO_DATA)){
		//glcdPut(rx_data & 255);
		glcdDrawChar((uint8_t)rx_data);
	}
	while(! ((rx_data=uart1_getc()) & UART_NO_DATA)){
		//glcdPut(rx_data & 255);
		glcdDrawChar((uint8_t)rx_data);
	}

//	if(glcd_Cursor.X < 5 || glcd_Cursor.Y < 16 || glcd_Cursor.Y > 162 || glcd_Cursor.X > 120) glcdMoveTo(5,16);
	//printf("%c",(rx_data & 255));

	//glcdWait(100);
}

/** Reads the input buffer from the ADC. Searches for the best trigger point.
 *  Calls disp_drawGrid() to display the output. */

volatile uint8_t min[4] = {255,255,255,255};
volatile uint8_t max[4] = {0,0,0,0};
volatile uint8_t mid[4] = {0,0,0,0};
volatile double freq[4] = {0,0,0,0};

void disp_graph(void) {
	if(adc_stopped() == 0) return;

	#define GR_W	20	//width of sub ... dash? unterteilung
	#define GR_H	20	//height of ???
	#define GR_WW	128	//width
	#define GR_HH	144	//height
	#define GR_X	2	//x-coord: upper-left
	#define GR_Y	15	//y-coord: upper-left


	//trigger
	uint16_t trigger_shift = 72*adc_channels;
	uint16_t GR_TRIG_BEFORE = ADC_BUF_SIZE - (GR_HH*adc_channels) + trigger_shift;

	int8_t trigger_old = 0;
	int8_t trigger_new = 0;
	int8_t trigger_highest = 0;
	uint16_t offset = 0;

	for(uint16_t x = trigger_shift; x < GR_TRIG_BEFORE; x+=adc_channels){
		trigger_old = adc[x] >> 1;
		trigger_new = adc[x + 3*adc_channels] >> 1;
		if((trigger_new-trigger_old) > trigger_highest){
			offset = x - trigger_shift;
			trigger_highest = trigger_new-trigger_old;
		}
	}
	
	min[0] = 255; min[1] = 255; min[2] = 255; min[3] = 255;
	max[0] = 0; max[1] = 0; max[2] = 0; max[3] = 0; 
	mid[0] = 0; mid[1] = 0; mid[2] = 0; mid[3] = 0;
	freq[0] = 0; freq[1] = 0; freq[2] = 0; freq[3] = 0; 
	for(uint8_t ch = 0; ch < adc_channels; ch++){
		for(uint16_t x = ch; x < ADC_BUF_SIZE; x+=adc_channels){
			if(adc[x] < min[ch]) min[ch] = adc[x];
			if(adc[x] > max[ch]) max[ch] = adc[x];
		}
	}
	for(uint8_t x = 0; x < adc_channels; x++) mid[x] = (max[x]-min[x])/2  + min[x];


	for(uint8_t ch = 0; ch < adc_channels; ch++){
		uint16_t old_pos = 0;
		int8_t under;		//currently under mid? 0 for no, 1 for yes
		int8_t old_under;
		double period = 0.0;
		
		if(adc[ch] < mid[ch]){ under = 0; old_under = 0; }
			else { under = 1; old_under = 1; }
		
		for(uint16_t x = ch; x < ADC_BUF_SIZE; x+=adc_channels){
			if(adc[x] > mid[ch]) under = 0;
			if(adc[x] < mid[ch]) under = 1;
			
			if(old_under == 1 && under == 0){
				period = (double)(x - old_pos)*adc_duration /adc_channels/ 1000000.0;
				if(old_pos != 0  &&  period != 0.0){
					if(freq[ch] == 0.0) freq[ch] = 1.0 / period;
					else 				freq[ch] = 0.8*freq[ch] + 0.2/period;
				}
				old_pos = x;
			}
			
			old_under = under;
		}

	}
	
	
	//draw in the display
	disp_drawGrid(&adc[offset], 64, trigger_shift/adc_channels);

	adc_init(1);
}

/** \todo Change from grid to coordinate axes. Origin is the trigger point and
 * zero Volt. */
void disp_drawGrid(volatile uint8_t toDraw[], uint8_t xaxis, uint8_t yaxis){
	//draw grid
	glcdSetColors(ShColor, BkColor);
	
	glcdLine(GR_X+xaxis, GR_Y, GR_X+xaxis, GR_Y+GR_HH); //horizontal
	glcdLine(GR_X, GR_Y+yaxis, GR_X+GR_WW, GR_Y+yaxis); //vertical
	
	/* x and y need to be signed, because for small xaxis and yaxis, the start
	 * can be negative */
	for(int16_t x = GR_X+xaxis+GR_W; x <= GR_X+GR_WW; x+=GR_W) glcdLine(x, GR_Y-3+yaxis, x, GR_Y+3+yaxis);
	for(int16_t x = GR_X+xaxis-GR_W; x >= GR_X      ; x-=GR_W) glcdLine(x, GR_Y-3+yaxis, x, GR_Y+3+yaxis);
		
	for(int16_t y = GR_Y+yaxis+GR_H; y <= GR_Y+GR_HH; y+=GR_H) glcdLine(GR_X-3+xaxis, y, GR_X+3+xaxis, y);
	for(int16_t y = GR_Y+yaxis-GR_H; y >= GR_Y      ; y-=GR_H) glcdLine(GR_X-3+xaxis, y, GR_X+3+xaxis, y);

	
	//replot data
	//init
	static uint8_t buffer[4][GR_HH];
	uint8_t old_coord[4] = {buffer[0][0], buffer[1][0], buffer[2][0], buffer[3][0]};
	static uint8_t old_adc_nr_channels = 1;
	for(uint8_t ch=0; ch < adc_channels; ch++)
		buffer[ch][0] = toDraw[ch] >> 1;
	glcdSetBkColor(BkColor);
	//start
	for(uint8_t y = 1; y < GR_HH; y++){
		//erase old lines
		glcdSetFgColor(BkColor);
		for(uint8_t ch=0; ch < old_adc_nr_channels; ch++){ //old_number!!!
			glcdLine(GR_X + old_coord[ch], y-1 + GR_Y, GR_X + buffer[ch][y], y + GR_Y);
			old_coord[ch] = buffer[ch][y];
			buffer[ch][y] = toDraw[y*adc_channels+ch] >> 1;
		}
		//draw new lines
		for(uint8_t ch=0; ch < adc_channels; ch++){
			switch(ch){
				case 0:
					glcdSetFgColor(WHITE);
					break;
				case 1:
					glcdSetFgColor(FgColor);
					break;
				case 2:
					glcdSetFgColor(GREEN);
					break;
				case 3:
					glcdSetFgColor(RED);
					break;
			}
			glcdLine(GR_X + buffer[ch][y-1], y-1 + GR_Y, GR_X + buffer[ch][y], y + GR_Y);
		}
	}
	old_adc_nr_channels = adc_channels;

	//info box
	#define INFO_X GR_X+GR_WW-55
	#define INFO_Y GR_Y+GR_HH-25
	glcdSetColors(FgColor, BkColor);
	int y = INFO_Y - 9;
	glcdMoveTo(INFO_X+2, y+=11); printf("td:");
	glcdMoveTo(INFO_X+2, y+=11); printf("fq:");
	y = INFO_Y - 9;
	uint32_t time = adc_duration*GR_H;
	if(time < 10000){
		glcdMoveTo(INFO_X+15, y+=11); printf(" %4dus ",(int16_t)(time));
	}else{
		glcdMoveTo(INFO_X+15, y+=11); printf(" %4dms ",(int16_t)(time/1000));
	}
	if(freq[0] < 10000){
		glcdMoveTo(INFO_X+15, y+=11); printf(" %4dHz ",(int16_t)(freq[0]));
	}else{
		glcdMoveTo(INFO_X+15, y+=11); printf(" %3dkHz ",(int16_t)(freq[0]/1000));
	}
}
