/** \file
*  \brief ADC
* 
*  Data acquisition.
* 
*  30 March 2006<br />
*  Sven Kreiss
*/

#ifndef ADC_H
#define ADC_H

#include "main.h"

#define ADC_BUF_SIZE 1700		///< Size of the input-buffer.
//#define ADC_DECR_BUF(a) ((a) != 0) ? (--a) : (a = ADC_BUF_SIZE-1)
//#define ADC_INCR_BUF(a) ((a) != ADC_BUF_SIZE-2) ? (++a) : (a = 0)

volatile uint8_t adc[ADC_BUF_SIZE];		///< input-buffer
extern volatile uint8_t adc_channels;	///< nr of active channels
volatile double adc_duration;			///< time for one sample point
extern volatile uint8_t adc_prescaler;	///< the current prescaler

void adc_init(uint8_t channel);				///< initialise ADC with "channel"
void adc_select_channel(uint8_t channel);	///< select "channel"
void adc_LED(void);							///< handels the LED output
void adc_off(void);							///< switches the ADC off
void adc_set_nr_channels(int8_t nr);		///< sets the nr of active channels
void adc_set_presc(int8_t presc);			///< sets the prescaler
void adc_next_channel(void);				///< switches to the next channel
int8_t adc_stopped(void);					///< checks, whether the ADC has stopped
void adc_stop (void);						///< stops the ADC


#endif
