/** \file
*  \brief menu
* 
*  "Data-backend" for the menu.
* 
*  03 April 2006<br />
*  Sven Kreiss
*/




#ifndef MENU_H
#define MENU_H

#include "main.h"



/**
 * \brief Main menu -- Mode
 *
 * Structur which holds the "interface"-information for the
 * main menu entries. */
typedef struct {
	void (*disp_func)(void);
	void (*control_func)(void);
	char *name;
} menu_main_struct;
volatile int8_t menu_now;						///< nr of current menu point
#define MENU_ANZ_MAIN	3						///< nr of main menu entries
extern volatile menu_main_struct menu_mains[];	///< array which holds one menu_main_struct for each entry


/**
 * \brief Properties
 *
 * "Interface"-information for the property-list.<br />
 * Note: This is a single property. The structure containing all the
 * properties for one menu is menu_prop_main_struct. Names are chosen badly
 * here. */
typedef struct {
	void (*set_value)(int8_t value);
	int8_t current_value;
	int8_t nr_values;
	char *prop_name;
	char *value_name[11];
} menu_prop_struct;

/// container for properties
typedef struct {
	int8_t nr_props;
	int8_t prop_now;
	menu_prop_struct properties[10];
} menu_prop_main_struct;
///array holding one menu_prop_main_struct for each property
extern volatile menu_prop_main_struct menu_props[MENU_ANZ_MAIN];
#define MENU_PROPS_NOW	menu_props[menu_now-1]								///< current properties array
#define MENU_CURRENT_PROP_NR	menu_props[menu_now-1].prop_now				///< nr of the current property
#define MENU_PROP_NOW	MENU_PROPS_NOW.properties[MENU_CURRENT_PROP_NR-1]	///< the current property




volatile void menu_init(void);			///< initialise menu
volatile void menu_main_set(int8_t nr);	///< set to menu "nr"

extern void menu_main_incr(void);		///< next menu
extern void menu_main_decr(void);		///< menu before
void menu_prop_set(int8_t);				///< set prop in argument active


extern void menu_start(void);			///< Handels pressed signal for button "start"
extern void menu_left(void);			///< Handels pressed signal for button "left"
extern void menu_up(void);				///< Handels pressed signal for button "up"
extern void menu_down(void);			///< Handels pressed signal for button "down"
extern void menu_right(void);			///< Handels pressed signal for button "right"



#endif
