/* \file
*  \brief micro-second(us) timer, source, Version 0.5.2
* 
*  Functions for precise time measurements.
* 
*  29 March 2006<br />
*  Sven Kreiss
*/



#include "ustimer.h"

volatile uint32_t us_time = 0;	///< internal counter




/** Initiates 16bit-Timer3 for the precise measurement.
 *  Enables Timer overflow interrupt. */
void us_timer_init(void)
{
	#define US_TIMER_PRESCALER 8	///< for XTAL > 8 MHz: 8, else: 1
	#define XTAL 11.0562			///< cpu-freq in MHz

	TCCR3A = 0;						//normal mode
	TCCR3B = (1<<CS31);				//CS31: Prescaler 8, CS00: Prescaler 1
	ETIMSK = (1<<TOIE3);			//enable Timer3 overflow interrupt
	//TIMSK = (1<<TOIE1);			//enable Timer1 overflow interrupt
	TCNT3 = 0;
}


/** The interrupt handler for the micro-second(us) timer. */
SIGNAL(SIG_OVERFLOW3)
{
	if(us_time < 0xFFFF) us_time++; //with 16Bit-Timer use 0xFFFF; 8bit: 0xFFFFFF
	else us_time = 0;
}



/** Calculates the current time from an incremented variable  and the
 *  counter register of the timer. */
uint32_t us_time_get(void)
{
	uint16_t timer;

	/*  It is really, really important to stop global interrupts before
	 *  reading 16bit registers. See the avr-libc FAQ! */
	cli();
	timer = TCNT3;
	sei();
	
	return ((us_time << 16) + timer);
}



/**
 * Uses us_time_get() to get the current time.
 * The if-condition at the end checks whether the later time is smaller. If so,
 * then an timer overflow is assumed and the appropriate action is taken that
 * the correct time can still be calculated. Therefore, the maximum
 * time one can measure is 2^32 micro-seconds.
 */
uint32_t us_time_get_difference(uint32_t time1)
{
	uint32_t time2;
	time2 = us_time_get();
	if(time2 >= time1) return (time2-time1);
	else return (0xFFFFFFFF - time1+time2); //2^32
}



/** Same as us_time_get_difference(), but returns the value in micro seconds. */
double us_time_get_difference_d(uint32_t time1)
{
	return ((double)(us_time_get_difference(time1) * US_TIMER_PRESCALER) / (double)XTAL);
}
