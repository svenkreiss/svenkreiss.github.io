/** \file
*  \brief ADC
* 
*  Data acquisition.
* 
*  30 March 2006<br />
*  Sven Kreiss
*/


#include "adc.h"

//between 1 and 7 //do not know why 1 and 0 give both prescaler two
volatile uint8_t adc_prescaler = 1;
//register uint8_t adc_count asm("r3");
volatile uint16_t adc_count = 0;
volatile int8_t adc_stop_flag = 1;		///< still needed ???

volatile uint32_t adc_starttime = 0;
volatile double adc_duration = 0;		//time for one sample point

volatile uint8_t adc_channels = 1; 	//nr_of_channels
volatile uint8_t adc_current_channel = 0;

/*
SIGNAL(SIG_ADC){
	adc[adc_count] = ADCH;	//8bit
	if((++adc_count) == ADC_BUF_SIZE) adc_stop();
}
*/

void adc_select_channel(uint8_t channel){
	if(channel == adc_current_channel) return;
	adc_current_channel = channel;
	
	//Input Channel selection; obersten beiden bits wählen externe Referenz, wenn 0
	//=> ADMUX entspricht Channel
	ADMUX = (channel-1) + (1<<ADLAR) + (1<<REFS0);
	//ADMUX |= (1<<ADLAR);	//left-align bits to allow to read the 8bit-value from ADCH
}

void adc_LED(void){
	if(adc_channels == 1) PORTA = (PORTA & 15) + (8 << 4); //& 15: assign only first 4 bits
	if(adc_channels == 2) PORTA = (PORTA & 15) + (12 << 4); //& 15: assign only first 4 bits
	if(adc_channels == 3) PORTA = (PORTA & 15) + (14 << 4); //& 15: assign only first 4 bits
	if(adc_channels == 4) PORTA = (PORTA & 15) + (15 << 4); //& 15: assign only first 4 bits
}

//not tested yet!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void adc_off(void){
	PORTA = PORTA & 15; //sets the upper 4 bits to zero

	ADCSRA = 0;
}

void adc_set_nr_channels(int8_t nr){
	adc_channels = nr;
}

void adc_next_channel(void){
	uint8_t new = adc_current_channel;
	
	new++;
	if(new > adc_channels) new = 1;
	adc_select_channel(new);
}


void adc_set_presc(int8_t presc){
	if(presc <= 7 && presc >= 1) adc_prescaler = presc;
}



void adc_single_channel(void){
	//fast measurement
	loop_until_bit_is_set(ADCSRA,ADIF);
	ADCSRA |= (1<<ADIF);
	adc[0] = ADCH;
	for(uint16_t x=0; x < ADC_BUF_SIZE; x++){
		loop_until_bit_is_set(ADCSRA,ADIF);
		adc[x] = ADCH;
//		adc_next_channel();
		ADCSRA |= (1<<ADIF);
	}
}

void adc_multi_channels(void){
	//fast measurement
	loop_until_bit_is_set(ADCSRA,ADIF);
	ADCSRA |= (1<<ADIF);
	adc[0] = ADCH;
	for(uint16_t x=0; x < ADC_BUF_SIZE; x++){
		adc_next_channel();
		loop_until_bit_is_set(ADCSRA,ADIF);
		adc[x] = ADCH;
		ADCSRA |= (1<<ADIF);

		loop_until_bit_is_set(ADCSRA,ADIF);
		ADCSRA |= (1<<ADIF);
		loop_until_bit_is_set(ADCSRA,ADIF);
		ADCSRA |= (1<<ADIF);
	}
}


void adc_init (uint8_t channel){
	adc_count = 0;
	adc_stop_flag = 0;

	adc_select_channel(channel);	//set the channel
	adc_current_channel = channel;  //save the number of the current channel
	adc_LED();

	ADCSRA = adc_prescaler & 7;		//& 7: only assign first three bits
	//AD Enable, AD Start Conversion, AD Free Running, AD Interrupt Enable
	adc_starttime = us_time_get();
	ADCSRA |= (1<<ADEN) | (1<<ADSC) | (1<<ADFR);//interrupt method: | (1<<ADIE);

	if(adc_channels == 1) adc_single_channel();
	else adc_multi_channels();

	//stop adc again
	adc_stop();
}


/** switches off the free running mode. 
 *  \todo still needed? */
void adc_stop (void) {
	ADCSRA &= ~(1<<ADSC) & ~(1<<ADFR) & ~(1<<ADIE);
	adc_stop_flag = 1;

	adc_duration = us_time_get_difference_d(adc_starttime) / ((double)ADC_BUF_SIZE / (double)adc_channels);
}

/** \todo still needed? */
int8_t adc_stopped(void){
	return adc_stop_flag;
}
