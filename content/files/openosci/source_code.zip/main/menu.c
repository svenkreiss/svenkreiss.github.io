/*
 *		menu.c
 *
 *		Sven Kreiss
 *		03 April 2006
 */

#include "menu.h"

/** Initialise the modes (or main menu entries).
 *  
 *  \todo changes needed: -FFT, +Logic Analyzer, +multimeter function (U, I, R)
 */
volatile menu_main_struct menu_mains[] = {
	{ &disp_graph, &control_graph, "Graph" },
	{ &disp_terminal, &control_graph, "TTY" },
	{ &disp_debugging, &control_graph, "FFT" },
};

/** Initialises all properties */
volatile menu_prop_main_struct menu_props[MENU_ANZ_MAIN] = {
	//graph-props
	{ 3, 1,	{
		{ &adc_set_presc, 1, 7, "Pr", {"1","2","3","4","5","6","7"} },
		{ &adc_set_nr_channels, 1, 4, "Ch", {"1","2","3","4"} },
		{ &bk_LED, 10, 11, "LED", {"0","1","2","3","4","5","6","7","8","9","10"} },
	} },
	//tty-props
	{ 4, 1,	{
		{ &usart_baudrate, 1, 11, "BR", {"2k4","4k8","9k6","14k4","19k2","28k8","38k4","57k6","76k8","115k2","230k4"} },
		{ &usart_setSync, 1, 2, "SY", {"dis","en"} },
		{ &usart_dataBits, 4, 5, "DB", {"5","6","7","8","9"} },
		{ &usart_stopBits, 2, 2, "SB", {"1","2"} },
	} },
	//fft-props
	{ 1, 1,
		{{ &adc_set_presc, 1, 5, "TB", {"1","2","3","4","5"} }} },
};




void menu_init(void){
	menu_main_set(1);
	menu_prop_set(1);
}


void menu_main_set(int8_t nr){
	if(nr <= MENU_ANZ_MAIN) menu_now = nr;
}

void menu_main_incr(void){
	if(menu_now < MENU_ANZ_MAIN)	menu_main_set(menu_now + 1);
	else 							menu_main_set(1);
}

void menu_main_decr(void){
	if(menu_now > 1)	menu_main_set(menu_now - 1);
	else 				menu_main_set(MENU_ANZ_MAIN);
}

void menu_prop_set(int8_t nr){
	if(nr <= MENU_PROPS_NOW.nr_props) MENU_PROPS_NOW.prop_now = nr;
}



void menu_start(void){}

void menu_left(void){
	if(MENU_CURRENT_PROP_NR > 1) MENU_PROPS_NOW.prop_now--;
	else MENU_PROPS_NOW.prop_now = MENU_PROPS_NOW.nr_props;
}
void menu_right(void){
	if(MENU_CURRENT_PROP_NR < MENU_PROPS_NOW.nr_props) MENU_PROPS_NOW.prop_now++;
	else MENU_PROPS_NOW.prop_now = 1;
}

void menu_up(void){
	if(MENU_PROP_NOW.current_value < MENU_PROP_NOW.nr_values)
		MENU_PROP_NOW.current_value++;
	MENU_PROP_NOW.set_value(MENU_PROP_NOW.current_value);
}
void menu_down(void){
	if(MENU_PROP_NOW.current_value > 1) MENU_PROP_NOW.current_value--;
	MENU_PROP_NOW.set_value(MENU_PROP_NOW.current_value);
}
