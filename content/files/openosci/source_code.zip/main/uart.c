/* \file
*  \brief UART
* 
*  Serial communication.
* 
*  ca 01 January 2006<br />
*  Sven Kreiss
*/

#include "uart.h"



//*******************************   U(S)ART0   **************************************


void usart_init(void) {
	//baudrate
//	UBRR0H = 0;	UBRR0L = 0;
//	UBRR1H = 0;	UBRR1L = 0;
	usart_baudrate(0);

	//erase data overflow flag
	UCSR0A &= ~(1<<DOR);
	UCSR1A &= ~(1<<DOR);

	//RXEN, TXEN, INTERRUPT ENABLE
	UCSR0B |= (1<<RXEN) | (1<<TXEN) | (1<<RXCIE);
	UCSR1B |= (1<<RXEN) | (1<<TXEN) | (1<<RXCIE);

	//2 stop bit, 8 data bit, synchronous mode
//	UCSR0C = (1<<USBS) | (3<<UCSZ0);// | (1<<UMSEL);
//	UCSR1C = (1<<USBS) | (3<<UCSZ0);// | (1<<UMSEL);
	usart_stopBits(1);
	usart_setSync(0);
	usart_dataBits(3);

	//activate internal PullUp for RX and XCK(if input)
	//DDRE = 255;
	PORTE |= (1<<PE0) | (1<<PE2);
	PORTD |= (1<<PD2) | (1<<PD5);

	uart_init(UART_BAUD_SELECT(9600, 11059200UL));
	uart1_init(UART_BAUD_SELECT(9600, 11059200UL));
}

void usart_off(void) {
	UCSR0B &= ~(1<<RXEN) & ~(1<<TXEN);
	UCSR1B &= ~(1<<RXEN) & ~(1<<TXEN);
}

void usart_baudrate(int8_t br) {
	uint16_t reg = 0;

	//all values for 11.0592MHz oscillator
	if	   (br == 0) reg = 287;	//2k4
	else if(br == 1) reg = 143;	//4k8
	else if(br == 2) reg = 71; //9k6
	else if(br == 3) reg = 47; //14k4
	else if(br == 4) reg = 35; //19k2
	else if(br == 5) reg = 23; //28k8
	else if(br == 6) reg = 17; //38k4
	else if(br == 7) reg = 11; //57k6
	else if(br == 8) reg = 8; //76k8
	else if(br == 9) reg = 5; //115k2
	else if(br == 10) reg = 2; //230k4

	UBRR0H = ((reg>>8) & 255); UBRR0L = reg & 255;
	UBRR1H = ((reg>>8) & 255); UBRR1L = reg & 255;

//	UBRR0H = 0; UBRR0L = 5;
//	UBRR1H = 0; UBRR1L = 5;
}

void usart_setSync(int8_t enable) {
	if(enable == 1){	//sync enabled
		UCSR0C |= (1<<UMSEL);
		UCSR1C |= (1<<UMSEL);
	}
	else if(enable == 0){				//sync disabled
		UCSR0C &= ~(1<<UMSEL);
		UCSR1C &= ~(1<<UMSEL);
	}
}

void usart_stopBits(int8_t sb) {
	if(sb == 0){		//1 stop bit
		UCSR0C &= ~(1<<USBS);
		UCSR1C &= ~(1<<USBS);
	}
	else if(sb == 1){	//2 stop bits
		UCSR0C |= (1<<USBS);
		UCSR1C |= (1<<USBS);
	}
}

void usart_dataBits(int8_t db) {
	if     (db == 0){ UCSR0C |= (0<<UCSZ0); UCSR1C |= (0<<UCSZ1); }	//5bits
	else if(db == 1){ UCSR0C |= (1<<UCSZ0); UCSR1C |= (1<<UCSZ1); }	//6bits
	else if(db == 2){ UCSR0C |= (2<<UCSZ0); UCSR1C |= (2<<UCSZ1); } //7bits
	else if(db == 3){ UCSR0C |= (3<<UCSZ0); UCSR1C |= (3<<UCSZ1); } //8bits
	else if(db == 4){ UCSR0C |= (15<<UCSZ0); UCSR1C |= (15<<UCSZ1); } //9bits
}
