/** \file
*   \brief micro-second(us) timer
* 
*  Functions for precise time measurements.
*  Tested with 
*	- Timer3, ATMega128, 16bit
*	- Timer1, ATMega16, 16bit
*
*  No tests with 8bit-Timers so far, but 
*  it should work with minor changes.
*  
*  \todo ustimer could become a project on its own.
* 
*  29 March 2006<br />
*  Sven Kreiss
*/


#ifndef USTIMER_H
#define USTIMER_H

#include <inttypes.h>
#include <avr/io.h>
#include <avr/signal.h>
#include <avr/interrupt.h>



void us_timer_init(void);		///< initiates the timer
uint32_t us_time_get(void);		///< get current time
uint32_t us_time_get_difference(uint32_t time1);	///< calculates the difference between a saved and the current time
double us_time_get_difference_d(uint32_t time1);	///< calculates the difference between a saved and the current time in micro-seconds


#endif
