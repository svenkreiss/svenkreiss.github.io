/** \file
*  \brief Display
* 
*  All graphical output is handled here.
*
*  03 April 2006<br />
*  Sven Kreiss
*/



#ifndef DISPLAY_H
#define DISPLAY_H

// *** extern: Thanks to Christian Kranz and Hagen Reddmann ***
#include <glcd.h>
#include "../libs/font/f9x14.h"
#include "../libs/font/f8x11.h"



#include <inttypes.h>
#include <stdio.h>		//printf, fdevopen, ...
#include <ctype.h>
#include <stdlib.h>
#include <string.h>


// *** intern: ***
#include "main.h"


//#define DISP_SPLASH	///< splash-screen is used at the beginning


void disp_init(void);			///< initialises display
void disp_off(void);			///< switches the display off
void disp_refresh(void);		///< refreshes the display
void disp_menu(void);			///< displays the menu
void disp_prop(void);			///< displays the properties
void disp_load_bitmap(void);	///< displays a bitmap (used by splash)
void disp_clean(void);			///< clean the display

//Routinen
void disp_debugging(void);		///< displays a debugging screen
void disp_graph(void);			///< displays the osci graph
void disp_drawGrid(volatile uint8_t toDraw[], uint8_t xaxis, uint8_t yaxis);	///< draws the grid and the data in the argument
void disp_terminal(void);		///< displays a terminal


#endif
